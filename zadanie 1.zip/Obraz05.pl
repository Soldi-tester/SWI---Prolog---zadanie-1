male(hawkeye).
male(capitan).
female(widow).
superpower(capitan,widow).


stronger(capitan,widow).
stronger(widow,hawkeye).

stronger(capitan,hawkeye):-stronger(capitan,widow),stronger(widow,hawkeye).
