female(yellow).
female(white).
female(dots).
wearnecklace(yellow,dots).


walksinsun(white,dots).
walksinshadow(yellow).

walksinshadow(yellow):-walksinsun(white,dots).

