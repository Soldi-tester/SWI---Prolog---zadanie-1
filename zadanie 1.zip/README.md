Obraz 02
?- wearnecklace(yellow,_).
true.
Sprawdza czy jeszcze oprócz yellow ktoś ma naszyjnik

?- wearnecklace(yellow,X).
X = dots.
Sprawdza kto ma naszyjnik

walksinshadow(yellow):-walksinsun(white,dots).
Opisuję regułe jeżeli yellow idzie w cieniu to white i dots idzie w cieniu
--------------------------

Obraz 05
?- stronger(capitan,hawkeye).
true .
Sprawdza czy Kapitan Ameryka jest silniejszy od Hawkeye za pomocą przechodności

?- stronger(capitan,X).
X = widow ;
X = hawkeye ;

?- 
Po wciśnięciu [Enter], a następnie [;] Wylistuje kto jest słabszy od Kapitana Ameryki
---------------------------

Obraz 06
'wife(X,Y)' opisuję relację że żoną Y jest X
'husband(X,Y)' opisuję relację że mężem Y jest X
reguła 'wife(queen,philip):-husband(philip,queen).' opisuje relację pomiędzy żoną a mężem