man(philip).
man(william).
man(charles).
woman(queen).
woman(catherine).
woman(camilla).
kids(george,charlotte).

wife(queen,philip).
wife(camilla,charles).
wife(catherine,william).

husband(philip,queen).
husband(charles,camilla).
husband(william,catherine).

wife(queen,philip):-husband(philip,queen).
wife(camilla,charles):-husband(charles,camilla).
wife(william,catherine):-husband(william,catherine).
